import numpy as np
import wave
import matplotlib.pyplot as plt

types = {
    1: np.int8,
    2: np.int16,
    4: np.int32
}

import glob
targetPattern = r"*.wav"
print(glob.glob(targetPattern))
filess=glob.glob(targetPattern)
# import os
# for root, dirs, files in os.walk("наполнение бокала водой"):
#     for filename in files:
#         filess.append(filename)
# print (filess)

freq=665
FREQUENCIES=[]
for file in ['1(1).wav', '1(2).wav', '3(1).wav', '3(2).wav', '5(1).wav', '5(2).wav', '7(1).wav', '7(2).wav', '9(1).wav', '9(2).wav']:
    wav = wave.open(file, mode="r")
    (nchannels, sampwidth, framerate, nframes, comptype, compname) = wav.getparams()
    # print(nchannels, sampwidth, framerate, nframes, comptype, compname)
    duration = nframes / framerate
    # peak = 256 ** sampwidth / 2

    content = wav.readframes(nframes)
    samples = np.fromstring(content, dtype=types[sampwidth])

    max_index = np.argmax(samples)
    channel = samples[max_index:max_index+25000:nchannels]
    from scipy.fft import rfft, rfftfreq

    yf = rfft(channel)
    yf = yf / yf[np.argmax(yf)]
    xf = rfftfreq(len(channel), 1 / framerate)
    FREQUENCIES.append((freq/xf[np.argmax(yf)])**0.5)
    print(file)
fig, ax= plt.subplots()
ax.scatter([i for i in range(1, 10, 2)], FREQUENCIES[::2])
ax.scatter([i for i in range(1, 10, 2)], FREQUENCIES[1::2])
# ax.plot([i for i in range(1, 10, 2)], [(1+1*993*0.038/(5*3100*0.0014)*(1-i/14)**4) for i in range (1, 10, 2) ])
print ([1/((FREQUENCIES[i]-1)*5*0.002/(1*998*0.038)/(1-i/9)**4) for i in range(1, 10, 2) ])
ax.grid()
plt.minorticks_on()
ax.grid('minor', c='grey', linestyle=':')
ax.hlines(1, 1, 9, color='k', linestyles='--', linewidth=1)
ax.set_xlabel(r'$d,$' 'см')
ax.set_ylabel(r'$(\nu_0 / \nu_d)^2$')
for i in FREQUENCIES[::2]:
    print ('%.3f' % i)
for i in FREQUENCIES[1::2]:
    print ('%.3f' % i)
plt.show()